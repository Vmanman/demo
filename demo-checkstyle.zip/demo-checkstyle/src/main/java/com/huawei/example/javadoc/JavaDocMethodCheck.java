/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package com.huawei.example.javadoc;

import com.huawei.example.exception.MyException;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-10-30
 */
public class JavaDocMethodCheck {
    public String goo(String str1) throws MyException {
        return str1 + "OK";
    }

    /**
     * 测试JavaDoc空行
     *
     * @param str1 输入
     * @return 返回
     * @throws MyException 异常
     */
    public String hoo(String str1) throws MyException {
        return str1 + "OK";
    }

    /**
     * 测试JavaDoc标签和描述的空格
     *
     * @param str1   输入
     * @return   返回
     * @throws MyException   异常
     */
    public String ioo(String str1) throws MyException {
        return str1 + "OK";
    }
}