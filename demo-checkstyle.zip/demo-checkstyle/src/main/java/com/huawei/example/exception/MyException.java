/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package com.huawei.example.exception;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-10-30
 */
public class MyException extends Exception {
    private static final long serialVersionUID = 2107170655901104668L;
}