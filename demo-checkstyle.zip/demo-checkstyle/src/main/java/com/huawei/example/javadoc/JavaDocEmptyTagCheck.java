/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package com.huawei.example.javadoc;

import com.huawei.example.exception.MyException;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-11-02
 */
public class JavaDocEmptyTagCheck {
    /**
     * 测试JavaDoc标签
     *
     * @param str1
     * @return 测试字符串
     * @throws MyException 异常
     */
    public String foo(String str1) throws MyException {
        return str1 + "OK";
    }
}