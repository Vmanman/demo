import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-12-16
 */
public class JavaTest {
    private static final Logger logger = LoggerFactory.getLogger(JavaTest.class);

    public static void main(String[] args) {
        logger.info("this is a info message! ");
    }
}