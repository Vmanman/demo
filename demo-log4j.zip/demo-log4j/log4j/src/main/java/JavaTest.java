import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class JavaTest {
    /**
     * 主程序入口
     *
     * @param args
     */
    public static void main(String[] args) {
        Logger log = LogManager.getLogger(LogManager.ROOT_LOGGER_NAME);

        log.trace("trace level");
        log.info("info level");
    }
}
