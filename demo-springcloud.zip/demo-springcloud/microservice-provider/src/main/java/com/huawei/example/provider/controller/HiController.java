package com.huawei.example.provider.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-10-29
 */
@RestController
public class HiController {
    @Value("${server.port}")
    String port;

    @RequestMapping("/hi")
    public String hi(@RequestParam(value = "name", defaultValue = "minbo") String name) {
        String result = "hi " + name + " , i am from port:" + port;
        System.out.println(result);
        return result;
    }
}