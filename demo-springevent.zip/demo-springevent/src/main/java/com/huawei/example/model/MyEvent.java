package com.huawei.example.model;

import lombok.Getter;
import lombok.Setter;

import org.springframework.context.ApplicationEvent;

/**
 * 自定义事件
 *
 * @author w00453985
 * @since 2020-10-29
 */
@Getter
@Setter
public class MyEvent extends ApplicationEvent {
    private String msg;

    private String email;

    private int signal;

    public MyEvent(Object source, String msg, String email, int signal) {
        super(source);
        this.msg = msg;
        this.email = email;
        this.signal = signal;
    }
}