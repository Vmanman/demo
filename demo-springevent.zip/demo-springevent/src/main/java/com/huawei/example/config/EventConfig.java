package com.huawei.example.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-10-29
 */
@Configuration
@ComponentScan("com.huawei.example")
public class EventConfig {

}