package com.huawei.example;

import com.huawei.example.config.EventConfig;
import com.huawei.example.publisher.EventPublisher;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-10-29
 */
public class SpringEventApplication {
    public static void main(String[] args) throws InterruptedException {
        AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(EventConfig.class);
        EventPublisher demoEventPublisher = context.getBean(EventPublisher.class);
        demoEventPublisher.pushEvent("现在是红灯，请不要闯红灯","wuzhiyong", 1);
        Thread.sleep(5000);
        demoEventPublisher.pushEvent("现在是绿灯，请有序过马路","wuzhiyong", 0);
        Thread.sleep(5000);
        demoEventPublisher.pushEvent("现在是红灯，请不要闯红灯","wuzhiyong", 1);

        context.close();
    }
}