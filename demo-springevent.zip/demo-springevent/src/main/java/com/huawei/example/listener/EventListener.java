package com.huawei.example.listener;

import com.huawei.example.model.MyEvent;

import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-10-29
 */
@Component
public class EventListener implements ApplicationListener<MyEvent> {
    @Async
    @Override
    public void onApplicationEvent(MyEvent event) {
        StringBuffer sb = new StringBuffer();
        sb.append(event.getEmail()).append("已收到提示：").append(event.getMsg());
        if (event.getSignal() == 1) {
            sb.append(", 停下等待。");
        } else {
            sb.append(", 可以过马路了。");
        }
        System.out.println(sb.toString());
    }
}