package com.huawei.example.publisher;

import com.huawei.example.model.MyEvent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-10-29
 */
@Component
public class EventPublisher {
    @Autowired
    private ApplicationContext applicationContext;

    public void pushEvent(String msg, String mail, int signal) {
        applicationContext.publishEvent(new MyEvent(this, msg, mail, signal));
    }
}