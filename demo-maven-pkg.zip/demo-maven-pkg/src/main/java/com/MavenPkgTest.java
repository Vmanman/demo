package com;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class MavenPkgTest {
    private static final Logger LOG = Logger.getLogger("log1");

    public static void main(String[] args) throws IOException {
        System.out.println("Maven package Test!");
        System.out.println("- bin");
        System.out.println("   |- start.sh");
        System.out.println("   |- ReadMe.txt");
        System.out.println("- conf");
        System.out.println("   |- wzy.properties");
        System.out.println("   |- log4j.properties");
        System.out.println("- lib");
        System.out.println("   |- log4j.jar");
        System.out.println("   |- demo-maven-pkg-1.0-SNAPSHOT.jar");
        System.out.println("- logs");
        System.out.println("   |- real time.log");

        LOG.info("This is a INFO message!");

        InputStream in = MavenPkgTest.class.getClassLoader().getResourceAsStream("wzy.properties");
        Properties prop = new Properties();
        prop.load(in);
        String value = prop.getProperty("abc");
        LOG.info("abc: " + value);
    }
}
