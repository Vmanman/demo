public class JavaTest {
    /**
     * 主程序入口
     *
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("abcd");
    }
}
