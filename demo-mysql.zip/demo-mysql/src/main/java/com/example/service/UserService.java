package com.example.service;

import com.example.api.UserDo;
import com.example.db.dao.UserDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2021-07-06
 */
@Service
public class UserService {
    private UserDao userDao;

    @Autowired
    public UserService(UserDao userDao) {
        this.userDao = userDao;
    }

    public void create(UserDo userDo) {
        userDao.insert(userDo);
    }

    public UserDo query(String id) {
        return userDao.query(id);
    }

    public void delete(String id) {
        userDao.delete(id);
    }
}