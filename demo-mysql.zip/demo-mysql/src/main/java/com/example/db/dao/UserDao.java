package com.example.db.dao;

import com.example.api.UserDo;
import com.example.db.mapper.UserMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2021-07-06
 */
@Component
public class UserDao {
    @Autowired
    private UserMapper userMapper;

    public void insert(UserDo userDo) {
        userMapper.insert(userDo);
    }

    public UserDo query(String id) {
        return userMapper.queryById(id);
    }

    public void delete(String id) {
        userMapper.delete(id);
    }
}