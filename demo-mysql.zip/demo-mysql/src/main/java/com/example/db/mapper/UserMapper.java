package com.example.db.mapper;

import com.example.api.UserDo;

import org.apache.ibatis.annotations.Param;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2021-07-06
 */
public interface UserMapper {
    void insert(@Param("userDo") UserDo userDo);

    UserDo queryById(String id);

    void delete(String id);
}