package com.example;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@ImportResource("classpath:applicationContext.xml")
@MapperScan("com.example.db.mapper")
public class AppMain {
    public static void main(String[] args) throws Exception {
        new SpringApplication(AppMain.class).run(args);
    }
}