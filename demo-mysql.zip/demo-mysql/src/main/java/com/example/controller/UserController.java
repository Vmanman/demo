package com.example.controller;

import com.example.api.UserDo;
import com.example.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2021-07-05
 */
@RequestMapping("/")
@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/create")
    @ResponseBody
    public void create(@RequestBody UserDo userDo) {
        userService.create(userDo);
    }

    @GetMapping("/query")
    @ResponseBody
    public UserDo query(String id) {
        return userService.query(id);
    }

    @GetMapping("/delete")
    @ResponseBody
    public void delete(String id) {
        userService.delete(id);
    }
}